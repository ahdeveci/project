import React from 'react';
import Hero from '../components/Hero';
import MigrationRoute from '../components/MigrationRoute';
import WetlandCard from '../components/WetlandCard';
import RamsarWidget from '../components/RamsarWidget';
import Charts from '../components/Charts';

const Home = () => {
  const routes = [
    {
      href: "#bosphorus",
      title: "Boğaz Göç Yolu",
      body: "İstanbul Boğazı üzerinden geçen göç yolu, yırtıcı kuşlar ve Sylvia türleri için önemli bir geçiş noktasıdır."
    },
    {
      href: "#caucasus",
      title: "Kafkasya Rotası",
      body: "Doğu Karadeniz üzerinden geçen bu rota, özellikle leylekler ve Sylvia türleri tarafından kullanılır."
    },
    {
      href: "#mediterranean",
      title: "Akdeniz Kıyı Şeridi",
      body: "Akdeniz kıyısı boyunca uzanan rota, flamingolar ve su kuşları için hayati önem taşır."
    }
  ];

  const wetlands = [
    {
      image: "https://images.unsplash.com/photo-1552083375-1447ce886485",
      title: "Kızılırmak Deltası",
      description: "Samsun'da bulunan delta, 359 kuş türüne ev sahipliği yapan, Karadeniz'in en büyük sulak alanıdır. Özellikle flamingolar ve Sylvia türleri için önemli bir yaşam alanıdır."
    },
    {
      image: "https://images.unsplash.com/photo-1584267385494-9fdd9a71ad75",
      title: "Gediz Deltası",
      description: "İzmir'de bulunan delta, Akdeniz'in en büyük flamingo kolonilerine ev sahipliği yapar. Her yıl binlerce flamingo burada ürer."
    },
    {
      image: "https://images.unsplash.com/photo-1621632361333-4649f0e589d4",
      title: "Sultan Sazlığı",
      description: "Kayseri'de bulunan bu alan, leylekler ve Sylvia türleri için önemli bir durak noktasıdır. İç Anadolu'nun en önemli sulak alanlarından biridir."
    }
  ];

  return (
    <main className="mx-auto p-4 max-w-[1200px] text-white text-xl leading-relaxed">
      <h1 className="text-6xl font-bold leading-none text-center mb-8">
        Türkiye'den Geçen <span className="bg-gradient-to-r from-emerald-500 via-lime-300 to-white bg-clip-text text-transparent">Kuş Göçleri</span>
      </h1>
      
      <Hero />

      <Charts/>
      
      <RamsarWidget />

      <section className="mb-16 mt-16">
        <h2 className="text-4xl mb-8 text-center">Önemli Göç Rotaları</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {routes.map((route) => (
            <MigrationRoute key={route.href} {...route} />
          ))}
        </div>
      </section>

      <section className="mb-16">
        <h2 className="text-4xl mb-8 text-center">Önemli Sulak Alanlar</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {wetlands.map((wetland) => (
            <WetlandCard key={wetland.title} {...wetland} />
          ))}
        </div>
      </section>
    </main>
  );
};

export default Home;